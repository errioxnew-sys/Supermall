from django.apps import AppConfig

class MallConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mall'
    verbose_name = 'SuperMall Platform'
